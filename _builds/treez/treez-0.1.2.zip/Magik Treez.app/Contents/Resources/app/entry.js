import { createApp } from './bridge.js';
import * as appMod from './src/main.js';

let FRONTEND;
try { FRONTEND = decodeURIComponent(new URL('./frontend', import.meta.url).pathname); }
catch { FRONTEND = tjs.exePath.replace(/\/[^/]*$/, '') + '/frontend'; }

const app = await createApp({
  htmlPath: FRONTEND + '/index.html',
  title: "Magik Treez",
  size: "260x420",
  version: "0.1.2",
  tinyjsVersion: "v0.25.3",
  id: "art.tarwin.treez",
  api: appMod.api ?? {},
  onMenu: appMod.onMenu,
  onTray: appMod.onTray,
  onHotkey: appMod.onHotkey,
  onContextMenu: appMod.onContextMenu,
  onSystem: appMod.onSystem,
  onOpenUrl: appMod.onOpenUrl,
  onOpenFiles: appMod.onOpenFiles,
  onNotificationClick: appMod.onNotificationClick,
  onNotificationAction: appMod.onNotificationAction,
  onMediaKey: appMod.onMediaKey,
  onWindowClosed: appMod.onWindowClosed,
  onClipboardChange: appMod.onClipboardChange,
  onUpdateAvailable: appMod.onUpdateAvailable,
  onAudioTap: appMod.onAudioTap,
  chrome: {"frame":false,"trafficLights":false,"transparent":true,"acceptsFirstMouse":true},
  update: {"url":"https://raw.githubusercontent.com/tarwin/tinyjsapp-examples/main/_builds/treez/manifest.json","auto":"daily"},
  activation: "accessory",
  readAccess: null,
  audioTap: null,
  contextMenu: true,
});
if (appMod.init) appMod.init(app);

await app.done;
tjs.exit(0);
