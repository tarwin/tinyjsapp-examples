import { createApp } from './bridge.js';
import * as appMod from './src/main.js';

let FRONTEND;
try { FRONTEND = decodeURIComponent(new URL('./frontend', import.meta.url).pathname); }
catch { FRONTEND = tjs.exePath.replace(/\/[^/]*$/, '') + '/frontend'; }

const app = await createApp({
  htmlPath: FRONTEND + '/index.html',
  title: "Nib",
  size: "560x468",
  version: "0.1.3",
  tinyjsVersion: "v0.25.3",
  id: "art.tarwin.nib",
  api: appMod.api ?? {},
  onMenu: appMod.onMenu,
  onTray: appMod.onTray,
  onHotkey: appMod.onHotkey,
  onContextMenu: appMod.onContextMenu,
  onSystem: appMod.onSystem,
  onOpenUrl: appMod.onOpenUrl,
  onOpenFiles: appMod.onOpenFiles,
  onNotificationClick: appMod.onNotificationClick,
  onNotificationAction: appMod.onNotificationAction,
  onMediaKey: appMod.onMediaKey,
  onWindowClosed: appMod.onWindowClosed,
  onClipboardChange: appMod.onClipboardChange,
  onUpdateAvailable: appMod.onUpdateAvailable,
  onAudioTap: appMod.onAudioTap,
  chrome: null,
  update: null,
  activation: null,
  readAccess: null,
  audioTap: null,
  contextMenu: true,
});
if (appMod.init) appMod.init(app);

await app.done;
tjs.exit(0);
